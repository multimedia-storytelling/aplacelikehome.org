# template-j341-project
These files serve as a template for each team's section of the website. These files are just a place to get started.

Bootstrap, Google fonts, and Font Awesome links are already added.

Further information will be provided in class about how the different sections of the course website will be integrated together and deployed.
